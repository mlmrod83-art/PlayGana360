PLAYGANA 360 - PROTOTIPO 1.0

1. Abre index.html en Chrome, Edge, Firefox o Safari.
2. Escribe un apodo y pulsa Guardar perfil.
3. Juega Trivia Ganadora o Memoria 360.
4. Tus puntos se guardan en el almacenamiento local de ese navegador.

PARA PUBLICAR GRATIS
- Crea una cuenta gratuita en GitHub.
- Sube index.html a un repositorio público.
- Activa GitHub Pages en Settings > Pages > Deploy from branch > main / root.
- Obtendrás una dirección web pública; revisa las condiciones y límites del servicio.

IMPORTANTE
- Los puntos son virtuales y no se pueden convertir en dinero.
- VIP es una demostración: no se cobran suscripciones.
- Los espacios publicitarios son marcadores: no hay anuncios reales.
- No hay registro de usuarios, backend, protección contra trampas ni pagos.
- Para monetizar de verdad hay que integrar un proveedor de pagos, cumplimiento fiscal y privacidad, y una red publicitaria aprobada.
