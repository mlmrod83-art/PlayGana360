-- Ejecuta en Supabase > SQL Editor.
-- No permite que un jugador se conceda membresía VIP.
create table if not exists public.vip_memberships (
  user_id uuid primary key references auth.users(id) on delete cascade,
  stripe_customer_id text unique,
  stripe_subscription_id text unique,
  status text not null default 'inactive' check (status in ('inactive','trialing','active','past_due','canceled','unpaid','incomplete','incomplete_expired','paused')),
  current_period_end timestamptz,
  updated_at timestamptz not null default now()
);
alter table public.vip_memberships enable row level security;
revoke all on public.vip_memberships from anon, authenticated;
-- No crear políticas de INSERT/UPDATE/DELETE para usuarios normales.
-- La futura Edge Function autenticará Stripe y actualizará la tabla con una clave privada.
-- La UI actual NO consulta esta tabla para desbloquear contenido.
