# PlayGana 360 v5 — registro funcional Supabase

## Publicación (desde GitHub, incluso Android)
1. En Supabase > Project Settings > API Keys (o Connect) copia **Project URL** y la clave **publishable** (o anon pública legacy).
2. Abre `config.js` y sustituye los dos marcadores. Solo estas claves **públicas** deben estar en GitHub. No publiques service_role, sb_secret, sk_test, sk_live ni whsec.
3. Sube **index.html, auth.js y config.js** a la raíz del repositorio `mlmrod83-art/PlayGana360`.
4. En Supabase > Authentication > URL Configuration confirma Site URL y Redirect URLs = https://mlmrod83-art.github.io/PlayGana360/
5. En Supabase > Authentication > Providers habilita Email y Confirm email.
6. Abre la página de GitHub Pages, crea cuenta con correo real, confirma el correo, vuelve al juego, inicia sesión, cierra sesión y prueba recuperación de contraseña.
7. Opcional: ejecuta `schema.sql` en SQL Editor para preparar la tabla de membresías.

## Lo que sí funciona
- Registro con correo y contraseña, confirmación de correo según configuración de Supabase, inicio y cierre de sesión, recuperación de contraseña.
- 3 juegos gratuitos. Botón de Stripe Checkout **solo en modo de prueba**.

## Lo que NO está implementado
- El enlace de Stripe no está vinculado a la cuenta Supabase; **no desbloquea VIP**.
- El código de los 17 juegos VIP permanece en `index.html` público, así que el bloqueo visual NO es una protección comercial segura.
- No hay Edge Function, webhook, portal de facturación ni recursos VIP protegidos.
- El apodo y los puntos todavía se guardan localmente en el dispositivo, no en Supabase.

## Próxima fase antes de cobrar
- Backend crea una Checkout Session para usuario autenticado con `client_reference_id` o metadata del `user_id`.
- Webhook verifica firma de Stripe y consulta estado de la suscripción; actualiza `vip_memberships` de forma idempotente.
- Endpoint protegido sirve código/recursos VIP solamente a usuarios con suscripción vigente; eliminar el código VIP del HTML público.
- Configurar Stripe Customer Portal, manejo de cancelaciones y renovaciones, y pruebas completas en Sandbox.

## Seguridad
- No pegues secretos en GitHub ni en el chat.
- RLS está habilitado y la tabla de membresías no concede escritura a clientes.
- Si el proyecto de Supabase tiene restricciones de email en el plan gratuito, configura SMTP antes de invitar al público.
